package com.zakaryalemsail.andifikra;
import android.content.*; import android.graphics.Color; import android.os.Bundle; import android.view.*; import android.widget.*; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 LinearLayout root; android.content.SharedPreferences prefs;
 public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("andi",0);home();}
 TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setPadding(24,18,24,18);v.setGravity(Gravity.RIGHT);return v;}
 Button b(String s){Button x=new Button(this);x.setText(s);x.setAllCaps(false);x.setTextSize(16);return x;}
 void base(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(20,20,20,20);root.setBackgroundColor(Color.WHITE);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);setContentView(root);}
 void home(){base();root.addView(t("💡 عندي فكرة",30));root.addView(t("خلي فكرتك تبدا بخطوة.",18));
 Button p=b("🚀 صايب مشروع");p.setOnClickListener(v->project());root.addView(p);
 Button s=b("📁 مشاريعي المحفوظة");s.setOnClickListener(v->saved());root.addView(s);
 root.addView(b("💼 بغيت نخدم"));root.addView(b("🎓 بغيت نتعلم"));root.addView(b("🤖 المساعد"));root.addView(t("صاحب التطبيق: Zakaria Lemsail",14));}
 void project(){base();root.addView(t("🚀 صايب مشروع",27));EditText i=e("شنو هي الفكرة ديالك؟"),m=e("الميزانية التقريبية"),sk=e("شنو كتقدر تدير؟"),c=e("شكون الزبناء المستهدفين؟"),l=e("فين غادي تخدم؟"),g=e("شنو الهدف ديالك فـ3 شهور؟");root.addView(i);root.addView(m);root.addView(sk);root.addView(c);root.addView(l);root.addView(g);
 Button x=b("✨ خرج ليا الخطة");x.setOnClickListener(v->{String p="الفكرة: "+i.getText()+"\nالميزانية: "+m.getText()+"\nالمهارات: "+sk.getText()+"\nالزبناء: "+c.getText()+"\nالمكان: "+l.getText()+"\nالهدف: "+g.getText()+"\n\nالخطوات الأولى:\n1. حدد المنتج أو الخدمة.\n2. شوف المنافسين والأسعار.\n3. جرب نسخة صغيرة.\n4. جيب أول زبناء.\n5. حسن المشروع حسب النتائج.";prefs.edit().putString("project",p).apply();plan(p);});root.addView(x);Button back=b("← رجوع");back.setOnClickListener(v->home());root.addView(back);}
 EditText e(String h){EditText e=new EditText(this);e.setHint(h);e.setPadding(16,10,16,10);return e;}
 void plan(String p){base();root.addView(t("📋 الخطة ديالك",27));root.addView(t(p,16));Button q=b("← الرئيسية");q.setOnClickListener(v->home());root.addView(q);}
 void saved(){base();root.addView(t("📁 مشاريعي",27));String p=prefs.getString("project","");root.addView(t(p.isEmpty()?"مازال ما حفظتي حتى مشروع.":p,16));Button q=b("← رجوع");q.setOnClickListener(v->home());root.addView(q);}
}
