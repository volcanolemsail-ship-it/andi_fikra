package com.zakaryalemsail.andifikra;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final int NAVY=Color.rgb(22,38,65), GREEN=Color.rgb(35,157,112),
            BG=Color.rgb(246,248,250), MUTED=Color.rgb(103,116,132), WHITE=Color.WHITE;
    private LinearLayout page, content;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("andi",MODE_PRIVATE);
        home();
    }

    private GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if(bold) v.setTypeface(null,Typeface.BOLD);
        v.setGravity(Gravity.RIGHT); v.setTextDirection(View.TEXT_DIRECTION_RTL);
        v.setPadding(0,6,0,6); return v;
    }
    private Button button(String label,boolean primary) {
        Button b=new Button(this); b.setText(label); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(primary?WHITE:NAVY); b.setBackground(shape(primary?GREEN:WHITE,24));
        b.setPadding(12,8,12,8); return b;
    }
    private void base(String title) {
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20,18,20,24); page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(page); setContentView(scroll);
        TextView brand=text("💡  عندي فكرة",25,NAVY,true); brand.setGravity(Gravity.RIGHT);
        page.addView(brand);
        if(title!=null) { TextView heading=text(title,22,NAVY,true); heading.setPadding(0,12,0,14); page.addView(heading); }
    }
    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(18,16,18,16); c.setBackground(shape(WHITE,22));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=14;
        c.setElevation(2); page.addView(c,lp); return c;
    }
    private void home() {
        base(null);
        LinearLayout hero=card(); hero.setBackground(shape(NAVY,26));
        TextView h=text("أفكارك تستاهل تبدا ✨",25,WHITE,true); hero.addView(h);
        TextView sub=text("حوّل الفكرة ديالك لخطوات واضحة، وتقدّم بشوية بشوية.",16,Color.rgb(224,235,245),false); hero.addView(sub);
        LinearLayout actions=card();
        addAction(actions,"🚀","صايب مشروع","خطّط للفكرة ديالك من البداية",()->project());
        addAction(actions,"📁","مشاريعي المحفوظة","رجع للأفكار والخطط اللي حفظتي",()->saved());
        addAction(actions,"💼","بغيت نخدم","نصائح عملية باش توجد راسك للخدمة",()->info("بغيت نخدم",
                new String[]{"حدّد المجال اللي باغي تخدم فيه.","وجد سيرة ذاتية واضحة ومختصرة.","جمع نماذج من خدمتك أو مشاريعك.","تدرّب على أسئلة المقابلات.","قدّم بانتظام وتابع الطلبات ديالك."}));
        addAction(actions,"🎓","بغيت نتعلم","اختار مهارة وتعلّمها بخطة بسيطة",()->info("بغيت نتعلم",
                new String[]{"اختار مهارة واحدة وهدف واضح.","قسّم التعلم لحصص قصيرة يومية.","طبّق كل درس فمشروع صغير.","راجع التقدم ديالك كل أسبوع.","شارك العمل ديالك وخذ ملاحظات."}));
        addAction(actions,"🤖","المساعد","أفكار وأسئلة تساعدك توضّح مشروعك",()->assistant());
        TextView footer=text("تطوير Zakaria Lemsail  •  النسخة 2.1",12,MUTED,false);
        footer.setGravity(Gravity.CENTER); page.addView(footer);
    }
    private void addAction(LinearLayout parent,String emoji,String title,String desc,Runnable click) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(12,12,12,12);
        row.setBackground(shape(BG,18));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=10; parent.addView(row,lp);
        TextView icon=text(emoji,25,GREEN,true); icon.setGravity(Gravity.CENTER); row.addView(icon,new LinearLayout.LayoutParams(54,-2));
        LinearLayout words=new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL);
        TextView t=text(title,17,NAVY,true), d=text(desc,13,MUTED,false);
        words.addView(t); words.addView(d); row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->click.run());
    }
    private EditText field(String hint) {
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(15); e.setSingleLine(false);
        e.setMinLines(1); e.setPadding(14,12,14,12); e.setBackground(shape(BG,14));
        e.setTextDirection(View.TEXT_DIRECTION_RTL); return e;
    }
    private void project() {
        base("🚀 صايب مشروع");
        LinearLayout c=card();
        c.addView(text("جاوب على هاد الأسئلة باش نوجدو ليك خطة أولية.",15,MUTED,false));
        EditText idea=field("شنو هي الفكرة ديالك؟"); EditText budget=field("الميزانية التقريبية"); EditText skills=field("شنو كتقدر تدير؟");
        EditText customers=field("شكون الزبناء المستهدفين؟"); EditText place=field("فين غادي تخدم؟"); EditText goal=field("شنو الهدف ديالك فـ3 شهور؟");
        EditText[] fields={idea,budget,skills,customers,place,goal};
        for(EditText e:fields){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=10;c.addView(e,p);}
        Button make=button("✨  خرج ليا الخطة",true); c.addView(make);
        make.setOnClickListener(v->{
            if(idea.getText().toString().trim().isEmpty()){idea.setError("كتب الفكرة ديالك");return;}
            String[] labels={"الفكرة","الميزانية","المهارات","الزبناء","المكان","الهدف فـ3 شهور"};
            StringBuilder plan=new StringBuilder("📌 خطتك الأولية\n\n");
            for(int i=0;i<fields.length;i++) plan.append(labels[i]).append(": ").append(fields[i].getText().toString().trim().isEmpty()?"ما تحددش":fields[i].getText().toString().trim()).append("\n");
            plan.append("\n🪜 الخطوات الأولى:\n1. حدّد المنتج أو الخدمة بالضبط.\n2. سول زبناء محتملين على الحاجة ديالهم.\n3. شوف المنافسين والأسعار.\n4. صايب نسخة بسيطة وجربها.\n5. حسب المصاريف والمداخيل.\n6. قيّم النتائج وحسّن المشروع.");
            String value=plan.toString(); prefs.edit().putString("project",value).apply(); plan(value);
        });
        Button back=button("رجوع للرئيسية",false); c.addView(back); back.setOnClickListener(v->home());
    }
    private void plan(String p) {
        base("📋 الخطة ديالك"); LinearLayout c=card(); TextView body=text(p,16,NAVY,false); c.addView(body);
        Button back=button("الرئيسية",true); c.addView(back); back.setOnClickListener(v->home());
    }
    private void saved() {
        base("📁 مشاريعي المحفوظة"); LinearLayout c=card();
        String p=prefs.getString("project","");
        c.addView(text(p.isEmpty()?"مازال ما حفظتي حتى مشروع. دخل لـ «صايب مشروع» باش تبدا.":p,16,NAVY,false));
        Button b=button("رجوع للرئيسية",true);c.addView(b);b.setOnClickListener(v->home());
    }
    private void info(String title,String[] tips) {
        base(title); LinearLayout c=card();
        for(int i=0;i<tips.length;i++) c.addView(text((i+1)+". "+tips[i],16,NAVY,false));
        Button b=button("رجوع للرئيسية",true);c.addView(b);b.setOnClickListener(v->home());
    }
    private void assistant() {
        base("🤖 المساعد"); LinearLayout c=card();
        c.addView(text("نقدر نعاونك ترتّب أفكارك. اختار سؤال باش تبدا:",16,NAVY,true));
        String[] qs={"شنو المشكل اللي كيحلّو المشروع ديالي؟","شكون أول زبون نقدر نوصل ليه؟","شنو أصغر تجربة نقدر ندير هاد الأسبوع؟","كيفاش نعرف واش الفكرة ديالي مطلوبة؟"};
        for(String q:qs){Button b=button(q,false);c.addView(b);b.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("فكّر فيها").setMessage(q+"\n\nكتب جوابك فملاحظاتك، ومن بعد جرّب خطوة صغيرة فالواقع.").setPositiveButton("حسناً",null).show());}
        Button back=button("رجوع للرئيسية",true);c.addView(back);back.setOnClickListener(v->home());
    }
}
